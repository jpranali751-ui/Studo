/* STUDO service worker: offline app shell + system notifications with action buttons */
const CACHE="studo-v4";
const SHELL=["./","index.html","icon-192.png","icon-512.png","manifest.webmanifest"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).catch(()=>{}));self.skipWaiting()});
self.addEventListener("activate",e=>{e.waitUntil((async()=>{for(const k of await caches.keys())if(k!==CACHE)await caches.delete(k);await self.clients.claim()})())});
self.addEventListener("fetch",e=>{
  const r=e.request;if(r.method!=="GET")return;const u=new URL(r.url);if(u.origin!==location.origin||u.pathname.startsWith("/api/"))return;
  e.respondWith(fetch(r).then(res=>{if(res.ok){const cp=res.clone();caches.open(CACHE).then(c=>c.put(r,cp))}return res}).catch(()=>caches.match(r).then(m=>m||caches.match("index.html"))))});
self.addEventListener("notificationclick",e=>{
  e.notification.close();const d=e.notification.data||{};const action=e.action||"";
  e.waitUntil((async()=>{const cs=await self.clients.matchAll({type:"window",includeUncontrolled:true});
    if(cs.length){const c=cs[0];try{await c.focus()}catch(_){}if(d.taskId&&action)c.postMessage({type:"studo-action",action,taskId:d.taskId})}
    else{let u="./";if(d.taskId&&action)u+="?act="+action+"&task="+d.taskId;await self.clients.openWindow(u)}})())});
