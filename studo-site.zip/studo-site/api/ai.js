// STUDO AI endpoint (Vercel serverless function). The API key stays here on the server.
// Needs the environment variable ANTHROPIC_API_KEY. Optional: AI_MODEL (default claude-haiku-5-5).
const SYSTEM = {
  friend: (c) => `You are "AI Best Friend" inside STUDO, a study app for students in classes 8-12 and exam aspirants. Be warm, supportive and practical, not childish and not over-motivational. Help with study routines, motivation, time management and general student productivity. Keep replies short and sweet: 2 to 4 short sentences, under 60 words, simple words, plain text, no markdown, no bullet lists. Ask at most one gentle follow-up question. For detailed academic explanations, suggest the Clear Doubts section. If a student seems to be in serious distress, kindly suggest talking to a trusted adult or counsellor.`,
  doubt: (c) => `You are "Clear Doubts" inside STUDO, an academic doubt-solving tutor. Student: ${c.className || "school student"}${c.board ? ", " + c.board : ""}${c.subject ? ". Subject: " + c.subject : ""}${c.topic ? ". Topic: " + c.topic : ""}. Reply format: first line is the direct answer in one sentence. Then "Why:" with one or two short sentences. Then "Example:" with one line, only if it truly helps. Keep the whole reply under 60 words, in simple words like a kind senior student. Plain text only: no markdown, no bullet lists, no headings; write maths like x^2 or 1/2. If the student asks to explain more, go deeper but stay under 150 words. You cannot see the student's textbook or syllabus; if an answer depends on one, say so rather than pretending to have checked it. Say when you are unsure.`,
  career: (c) => `You are "Career Guidance" inside STUDO, speaking with an Indian school student (${c.className || "class unknown"}${c.board ? ", " + c.board : ""}). Give balanced, honest guidance on streams, courses, entrance exams and careers. Ask about interests and strengths when helpful. Keep replies short and sweet (under 80 words), simple words, plain text, no markdown, no long lists. Never guarantee outcomes, and remind the student to confirm eligibility, dates and fees on official websites because they change.`,
  plan: () => `You output only valid JSON, with no prose and no markdown fences.`,
};
const hits = new Map(); // best-effort per-IP limit (resets when the function restarts)
const LIMIT = 40, WINDOW = 3600e3;
const clean = (v, n) => String(v == null ? "" : v).replace(/[\r\n]+/g, " ").slice(0, n);

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ code: "method" });
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return res.status(404).json({ code: "unavailable" });
  let b = req.body; if (typeof b === "string") { try { b = JSON.parse(b); } catch { b = {}; } } b = b || {};
  const mode = String(b.mode || "");
  if (!SYSTEM[mode]) return res.status(400).json({ code: "bad_request" });
  const ip = clean(req.headers["x-forwarded-for"] || "anon", 60).split(",")[0].trim();
  const now = Date.now(); const arr = (hits.get(ip) || []).filter((t) => now - t < WINDOW);
  if (arr.length >= LIMIT) return res.status(429).json({ code: "rate_limited" });
  arr.push(now); hits.set(ip, arr);
  if (hits.size > 5000) hits.clear();
  const maxLen = mode === "plan" ? 6000 : 2000;
  let msgs = (Array.isArray(b.messages) ? b.messages : []).slice(-12)
    .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim())
    .map((m) => ({ role: m.role, content: m.content.slice(0, maxLen) }));
  while (msgs.length && msgs[0].role !== "user") msgs.shift();
  if (!msgs.length || msgs[msgs.length - 1].role !== "user") return res.status(400).json({ code: "bad_request" });
  const c = b.ctx || {};
  const ctx = { className: clean(c.className, 30), board: clean(c.board, 30), subject: clean(c.subject, 50), topic: clean(c.topic, 80) };
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: process.env.AI_MODEL || "claude-haiku-5-5", max_tokens: mode === "plan" ? 4000 : 400, system: SYSTEM[mode](ctx), messages: msgs }),
    });
    if (r.status === 429) return res.status(429).json({ code: "rate_limited" });
    if (!r.ok) return res.status(502).json({ code: "server" });
    const j = await r.json();
    const text = (j.content || []).filter((x) => x.type === "text").map((x) => x.text).join("").trim();
    return res.status(200).json({ text });
  } catch (e) {
    return res.status(502).json({ code: "server" });
  }
};
